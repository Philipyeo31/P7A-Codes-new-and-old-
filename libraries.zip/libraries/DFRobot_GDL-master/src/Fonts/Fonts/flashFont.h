

const gdl_Glyph_t flashFonts[] PROGMEM = {
0x0, 0, 16, 16, 0x0, 0x0, 0x10

};
const gdl_Font_t flashFont PROGMEM = {
  NULL,(gdl_Glyph_t *)flashFonts,FONT_TYPE_FLASH,0,16
};                  